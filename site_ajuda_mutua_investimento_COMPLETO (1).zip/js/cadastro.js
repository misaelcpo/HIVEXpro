
document.getElementById("cadastroForm").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Cadastro realizado com sucesso! Aguarde a confirmação do pagamento para liberar sua conta.");
});
